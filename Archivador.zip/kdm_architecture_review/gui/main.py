from py2kdm_gui.main import main


if __name__ == "__main__":
    raise SystemExit(main())
