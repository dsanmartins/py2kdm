from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QHeaderView,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


class PipelineStatePanel(QWidget):
    """
    Displays the state of the py2kdm process based on generated artifacts.

    The Path column shows expected paths, but explicitly marks them as EXISTS
    or MISSING to avoid confusion after cleaning outputs.
    """

    STEPS = [
        ("static_extraction", "Static extraction", None),
        ("dynamic_analysis", "Dynamic analysis (Python)", None),
        ("architecture_recovery", "Architecture recovery", None),
        ("structure_kdm", "KDM generation", "model.structure.kdm.xmi"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(
            ["Step", "Status", "Artifact", "Path / Availability"]
        )
        self.table.horizontalHeader().setSectionResizeMode(
            0,
            QHeaderView.ResizeMode.ResizeToContents,
        )
        self.table.horizontalHeader().setSectionResizeMode(
            1,
            QHeaderView.ResizeMode.ResizeToContents,
        )
        self.table.horizontalHeader().setSectionResizeMode(
            2,
            QHeaderView.ResizeMode.ResizeToContents,
        )
        self.table.horizontalHeader().setSectionResizeMode(
            3,
            QHeaderView.ResizeMode.Stretch,
        )

        layout.addWidget(self.table)

    def refresh(
        self,
        output_dir: Path,
        dynamic_enabled: bool,
        language: str = "python",
    ) -> dict[str, str]:
        output_dir = Path(output_dir)
        language = self._normalize_language(language)
        state = self.compute_state(
            output_dir=output_dir,
            dynamic_enabled=dynamic_enabled,
            language=language,
        )
        self._render_state(
            state=state,
            output_dir=output_dir,
            dynamic_enabled=dynamic_enabled,
            language=language,
        )
        self.set_path_values(
            output_dir=output_dir,
            dynamic_enabled=dynamic_enabled,
            language=language,
        )
        return state

    def compute_state(
        self,
        output_dir: Path,
        dynamic_enabled: bool,
        language: str = "python",
    ) -> dict[str, str]:
        output_dir = Path(output_dir)
        language = self._normalize_language(language)
        basename = self._model_basename(language)

        artifacts = {
            "static_extraction": output_dir / f"{basename}.json",
            "dynamic_analysis": output_dir / f"{basename}.runtime_enriched.combined.json",
            "architecture_recovery_runtime": output_dir / f"{basename}.runtime_enriched.architecture.json",
            "architecture_recovery_static": output_dir / f"{basename}.architecture.json",
            "pre_review_runtime": output_dir / f"{basename}.runtime_enriched.ai_architecture.json",
            "pre_review_static": output_dir / f"{basename}.ai_architecture.json",
            "human_review": output_dir / f"{basename}.reviewed_architecture.json",
            "structure_kdm": output_dir / "model.structure.kdm.xmi",
            "final_kdm": output_dir / "model.reviewed.kdm.xmi",
        }

        return {
            "static_extraction": "done" if artifacts["static_extraction"].exists() else "pending",
            "dynamic_analysis": self._dynamic_state(
                artifacts=artifacts,
                dynamic_enabled=dynamic_enabled,
                language=language,
            ),
            "architecture_recovery": self._first_existing_state(
                artifacts["architecture_recovery_runtime"],
                artifacts["architecture_recovery_static"],
            ),
            "pre_review_agents": self._first_existing_state(
                artifacts["pre_review_runtime"],
                artifacts["pre_review_static"],
            ),
            "human_review": "done" if artifacts["human_review"].exists() else "pending",
            "structure_kdm": "done" if artifacts["structure_kdm"].exists() else "pending",
            "final_kdm": "done" if artifacts["final_kdm"].exists() else "pending",
        }

    def _dynamic_state(
        self,
        artifacts: dict[str, Path],
        dynamic_enabled: bool,
        language: str,
    ) -> str:
        if language == "java":
            return "disabled"

        if not dynamic_enabled:
            return "skipped"

        return "done" if artifacts["dynamic_analysis"].exists() else "pending"

    def _first_existing_state(self, *paths: Path) -> str:
        return "done" if any(path.exists() for path in paths) else "pending"

    def _artifact_for_step(
        self,
        output_dir: Path,
        step_id: str,
        dynamic_enabled: bool,
        language: str,
    ):
        output_dir = Path(output_dir)
        language = self._normalize_language(language)
        basename = self._model_basename(language)

        if step_id == "static_extraction":
            return output_dir / f"{basename}.json"

        if step_id == "dynamic_analysis":
            if language == "java":
                return None
            return output_dir / f"{basename}.runtime_enriched.combined.json"

        if step_id == "architecture_recovery":
            runtime_path = output_dir / f"{basename}.runtime_enriched.architecture.json"
            static_path = output_dir / f"{basename}.architecture.json"
            return runtime_path if runtime_path.exists() or dynamic_enabled else static_path

        if step_id == "pre_review_agents":
            runtime_path = output_dir / f"{basename}.runtime_enriched.ai_architecture.json"
            static_path = output_dir / f"{basename}.ai_architecture.json"
            return runtime_path if runtime_path.exists() or dynamic_enabled else static_path

        if step_id == "human_review":
            return output_dir / f"{basename}.reviewed_architecture.json"

        if step_id == "structure_kdm":
            return output_dir / "model.structure.kdm.xmi"

        if step_id == "final_kdm":
            return output_dir / "model.reviewed.kdm.xmi"

        return None

    def _render_state(
        self,
        state: dict[str, str],
        output_dir: Path,
        dynamic_enabled: bool,
        language: str,
    ):
        self.table.setRowCount(0)

        for step_id, label, default_artifact_name in self.STEPS:
            row = self.table.rowCount()
            self.table.insertRow(row)

            status = state.get(step_id, "pending")
            path = self._artifact_for_step(output_dir, step_id, dynamic_enabled, language)

            if step_id == "dynamic_analysis" and language == "java":
                artifact_name = "disabled for Java"
            elif path is not None:
                artifact_name = path.name
            else:
                artifact_name = default_artifact_name or "runtime/static variant"

            self.table.setItem(row, 0, QTableWidgetItem(label))
            self.table.setItem(row, 1, QTableWidgetItem(status))
            self.table.setItem(row, 2, QTableWidgetItem(artifact_name))
            self.table.setItem(row, 3, QTableWidgetItem(""))

    def set_path_values(
        self,
        output_dir: Path,
        dynamic_enabled: bool,
        language: str = "python",
    ):
        output_dir = Path(output_dir)
        language = self._normalize_language(language)

        for row, (step_id, _, _) in enumerate(self.STEPS):
            path = self._artifact_for_step(output_dir, step_id, dynamic_enabled, language)

            if step_id == "dynamic_analysis" and language == "java":
                self.table.setItem(
                    row,
                    3,
                    QTableWidgetItem(
                        "DISABLED: Java projects use static KDM-based recovery."
                    ),
                )
                continue

            if path is not None:
                status = "EXISTS" if path.exists() else "MISSING"
                self.table.setItem(row, 3, QTableWidgetItem(f"{status}: {path}"))

    def _normalize_language(self, language: str) -> str:
        language = (language or "python").lower()
        return language if language in {"python", "java"} else "python"

    def _model_basename(self, language: str) -> str:
        return "java_model" if language == "java" else "python_model"
